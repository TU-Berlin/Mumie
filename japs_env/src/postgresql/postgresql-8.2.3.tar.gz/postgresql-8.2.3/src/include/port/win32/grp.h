/* $PostgreSQL: pgsql/src/include/port/win32/grp.h,v 1.4 2006/10/04 00:30:10 momjian Exp $ */
