#ifndef			BYTE_ORDER
#ifdef			MIPSEB
#define			BYTE_ORDER		BIG_ENDIAN
#endif

#endif
